Name : Amit Erez
Id : 213760689

I did not use any resources other than websites that provide some details on Java syntax.
